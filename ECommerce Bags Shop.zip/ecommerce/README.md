
This is an eCommerce website designed using HTML, CSS, JS, Bootstrap, PHP and integrated with MySQLi database. The information of all users, items as well as the items purchased by each user will be stored securely in the database. 
Xampp server should be on, in order to run the website on your local computer.

Steps to Run the Website:
->Add the folder in the right xampp htdocs path.
-> Import the database "store.sql" in your php admin.
->In your browser, type localhost/ecommerce/index.php
->the website will open and you can test the working.


