<!-- this code is footer navigation bar in website -->
<footer>
    <div class="container">
        <center>
            <p>Copyright &copy: Bags Store. All Rights Reserved  |  Contact Us: +355 69 233 4578</p>    
        </center>
    </div>
    <!--To translate the page into any language, provided by Google-->
    <div id="google_translate_element"></div>
<script>
function google_translate_elementInit(){
    new google.translate.TranslateElement({ pageLanguage: 'en'}, 'google_translate_element');
}</script>
<script src="//translate.google.com/translate_a/element.js?cb=google_translate_elementInit"></script>
</footer>